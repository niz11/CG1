function degToRad(deg)
{
  return deg * 0.0174532925;
}
function radToDeg(rad)
{
  return rad * 57.2958;
}

THREE.Vector3.XAxis = new THREE.Vector3( 1, 0, 0 );
THREE.Vector3.YAxis = new THREE.Vector3( 0, 1, 0 );
THREE.Vector3.ZAxis = new THREE.Vector3( 0, 0, 1 );
