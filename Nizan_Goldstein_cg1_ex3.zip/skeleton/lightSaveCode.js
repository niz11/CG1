// Check
var time = -performance.now() * 0.0003;
this.scene.children[0].position.x = Math.sin(time * 1.7) * 300;
this.scene.children[0].position.y = Math.cos(time * 1.5) * 400;
this.scene.children[0].position.z = Math.cos(time * 1.3) * 300;

this.scene.children[1].position.x = Math.sin(time * 1.7) * 300;
this.scene.children[1].position.y = Math.cos(time * 1.5) * 400;
this.scene.children[1].position.z = Math.cos(time * 1.3) * 300;

// var sphereSize = 10;
// lightHelper = new THREE.PointLightHelper(light, sphereSize);
// lightHelper2 = new THREE.PointLightHelper(light2, sphereSize);
// this.scene.add(lightHelper2);
// this.scene.add(lightHelper);

var sphere = new THREE.SphereBufferGeometry(0.5, 16, 8);
var light = new THREE.PointLight(0xffffcc, 1, 100);
light.add(
  new THREE.Mesh(sphere, new THREE.MeshBasicMaterial({ color: 0xff0040 }))
);
light.position.set(10, 30, 15);
this.scene.add(light);

var light2 = new THREE.PointLight(0xffffcc, 1, 100);
light2.add(
  new THREE.Mesh(sphere, new THREE.MeshBasicMaterial({ color: 0xff0040 }))
);
light2.position.set(10, -30, -15);
this.scene.add(light2);
