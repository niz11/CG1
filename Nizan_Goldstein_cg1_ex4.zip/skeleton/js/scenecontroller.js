var SceneController = function(document) {
  this.texScene = new THREE.Scene();
  this.texScene.background = new THREE.Color(0xf0f0f0);
  this.texScene.fog = new THREE.Fog(0x000000, 1500, 4000);
  this.texRenderer = new THREE.WebGLRenderer({ antialias: true });

  this.scene = new THREE.Scene();
  this.scene.background = new THREE.Color(0x000000);
  this.scene.fog = new THREE.Fog(0x000000, 1500, 4000);
  this.renderer = new THREE.WebGLRenderer({ antialias: true });

  this.stats = new Stats();

  this.gui = new dat.GUI();
};

SceneController.prototype.setup = function() {
  this.texRenderer.setPixelRatio(window.devicePixelRatio);
  this.texRenderer.setSize(window.innerWidth / 2 - 20, window.innerHeight);
  document.body.appendChild(this.texRenderer.domElement);
  this.texRenderer.autoClear = false;

  this.renderer.setPixelRatio(window.devicePixelRatio);
  this.renderer.setSize(window.innerWidth / 2 - 20, window.innerHeight);
  this.renderer.setFaceCulling(THREE.CullFaceNone);
  document.body.appendChild(this.renderer.domElement);
  this.renderer.autoClear = false;

  //add performance logging
  this.stats.showPanel(0); // 0: fps, 1: ms, 2: mb, 3+: custom
  document.body.appendChild(this.stats.dom);

  this.textureCanvas = document.getElementsByTagName("canvas")[0];

  this.setupGUI();
  this.setupCamera();
  this.setupControls();
  this.setupLight();
  this.setupGeometry();

  this.render();
  this.animate();
};

SceneController.prototype.setupGUI = function() {
  this.params = {
    screenController: this,
    texImg: "earth",
    model: "quad",
    texStyle: "Nearest",
    sMapping: false,
    envMapping: false,
    drawSilhouette: false,
    bumpMap: false,
    fixSMapping: false,
    pen: false
  };

  var texNames = [
    "earth",
    "colors",
    "disturb",
    "checker",
    "checkerl",
    "rings",
    "wood"
  ];

  this.gui
    .add(this.params, "texImg", texNames)
    .name("Texture Images")
    .onChange(function(newValue) {
      this.object.screenController.changeTexture();
    });
  this.gui
    .add(this.params, "model", ["quad", "box", "sphere", "torus"])
    .name("3D Model")
    .onChange(function(newValue) {
      this.object.screenController.changeModel();
    });
  this.gui
    .add(this.params, "texStyle", [
      "Nearest",
      "Linear",
      "MipMap Nearest",
      "MipMap Linear"
    ])
    .name("Texture Style")
    .onChange(function(newValue) {
      this.object.screenController.changeTextureStyle();
    });

  this.gui
    .add(this.params, "sMapping")
    .name("Spherical mapping")
    .onChange(function(newValue) {
      this.object.screenController.sphericalMap();
    });
  this.gui
    .add(this.params, "envMapping")
    .name("Environment mapping")
    .onChange(function(newValue) {
      this.object.screenController.envMap();
    });
  this.gui
    .add(this.params, "drawSilhouette")
    .name("Draw silhouette")
    .onChange(function(newValue) {
      this.object.screenController.silhouetteShaders();
    });
  this.gui
    .add(this.params, "bumpMap")
    .name("Bump map")
    .onChange(function(newValue) {
      this.object.screenController.bumpMap();
    });
  this.gui
    .add(this.params, "fixSMapping")
    .name("Fixed spherical mapping")
    .onChange(function(newValue) {
      this.object.screenController.fixSphericalMap();
    });
  this.gui
    .add(this.params, "pen")
    .name("Pen drawing")
    .onChange(function(newValue) {
      this.object.screenController.penDrawing();
    });

  this.gui.open();
};

SceneController.prototype.changeTexture = function() {
  //Updating left screen
  this.texScene.remove(this.mesh2);
  this.texture = new THREE.TextureLoader().load(
    `./js/textures/${this.params.texImg}.jpg`
  );

  // immediately use the texture for material creation
  this.material2 = new THREE.MeshBasicMaterial({ map: this.texture });
  var geometry2 = new THREE.PlaneBufferGeometry(1, 1);
  this.mesh2 = new THREE.Mesh(geometry2, this.material2);

  this.texScene.add(this.mesh2);

  //Update right screen
  this.geometry = this.mesh.geometry;
  this.scene.remove(this.mesh);

  // immediately use the texture for material creation
  this.material = new THREE.MeshBasicMaterial({ map: this.texture });
  this.mesh = new THREE.Mesh(this.geometry, this.material);

  this.scene.add(this.mesh);

  this.render();
};

SceneController.prototype.changeTextureStyle = function() {
  // THREE.NearestFilter;
  // THREE.NearestMipMapNearestFilter
  // THREE.LinearFilter;
  // THREE.LinearMipMapLinearFilter;
  this.params.texStyle === "Nearest"
    ? (this.texture.magFilter = THREE.NearestFilter)
    : this.params.texStyle === "Liner"
    ? (this.texture.magFilter = THREE.LinearFilter)
    : this.params.texStyle === "MipMap Nearest"
    ? ((this.texture.minFilter = THREE.NearestMipMapNearestFilter),
      (this.texture.magFilter = THREE.NearestFilter))
    : ((this.texture.minFilter = THREE.LinearMipMapLinearFilter),
      (this.texture.magFilter = THREE.LinearFilter));
  this.texture.needsUpdate = true;

  //magFilter or minfiler or something like it
  this.uniforms.texture.value = this.texture;
  this.mesh.material.needsUpdate = true;

  this.render();
};

SceneController.prototype.changeModel = function() {
  if (this.params.model.localeCompare("quad") === 0)
    this.mesh.geometry = new THREE.PlaneBufferGeometry(0.5, 0.5);
  else if (this.params.model.localeCompare("box") === 0)
    this.mesh.geometry = new THREE.BoxGeometry(0.2, 0.2, 0.2);
  else if (this.params.model.localeCompare("sphere") === 0)
    this.mesh.geometry = new THREE.SphereGeometry(0.2, 30, 30);
  else if (this.params.model.localeCompare("torus") === 0) {
    window.console.log(this.params.model);
    this.mesh.geometry = new THREE.TorusGeometry(0.1, 0.05, 8, 10);
  }
  this.render();
};

SceneController.prototype.setupCamera = function() {
  var VIEW_ANGLE = 35;
  var ASPECT_RATIO = window.innerWidth / 2 / window.innerHeight;
  var NEAR_PLANE = 0.01;
  var FAR_PLANE = 5000;

  this.texCamera = new THREE.PerspectiveCamera(
    VIEW_ANGLE,
    ASPECT_RATIO,
    NEAR_PLANE,
    FAR_PLANE
  );
  this.texCamera.position.z = 2;
  this.texCamera.lookAt(this.texScene.position);

  this.camera = new THREE.PerspectiveCamera(
    VIEW_ANGLE,
    ASPECT_RATIO,
    NEAR_PLANE,
    FAR_PLANE
  );
  this.camera.position.z = 2;
  this.camera.lookAt(this.scene.position);
};

SceneController.prototype.setupControls = function() {
  this.controls = new THREE.TrackballControls(
    this.camera,
    this.renderer.domElement
  );
  this.controls.rotateSpeed = 3.0;
  this.controls.zoomSpeed = 1.2;
  this.controls.panSpeed = 0.8;
  this.controls.noZoom = false;
  this.controls.noPan = false;
  this.controls.staticMoving = true;
  this.controls.dynamicDampingFactor = 0.3;
  this.controls.keys = [65, 83, 68];
  this.controls.addEventListener("change", this.render.bind(this));
  this.controls.minDistance = 0.1;
  this.controls.maxDistance = 10;
};

SceneController.prototype.sphericalMap = function() {
  if (this.params.sMapping) {
    //Spherical shader
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShaderSphere3").textContent,
      fragmentShader: document.getElementById("fragmentShaderSphere3")
        .textContent
    });
  } else {
    this.uniforms.texture.value = this.texture;
    //Regular shader
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShader").textContent,
      fragmentShader: document.getElementById("fragmentShader").textContent
    });
  }
  console.log(this.material);

  this.mesh.material = this.material;

  this.render();
};

SceneController.prototype.silhouetteShaders = function() {
  if (this.params.drawSilhouette) {
    //Regular shader
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShaderSilhouette")
        .textContent,
      fragmentShader: document.getElementById("fragmentShaderSilhouette")
        .textContent
    });
  } else {
    this.uniforms.texture.value = this.texture;
    //Regular shader
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShader").textContent,
      fragmentShader: document.getElementById("fragmentShader").textContent
    });
  }
  this.mesh.material = this.material;
  //Here is another solution, without using any shader .
  // var outlineMaterial1 = new THREE.MeshBasicMaterial({
  //   color: 0xff0000,
  //   side: THREE.BackSide
  // });
  // var outlineMesh1 = new THREE.Mesh(this.mesh.geometry, outlineMaterial1);
  // outlineMesh1.position = this.mesh.geometry.position;
  // outlineMesh1.scale.multiplyScalar(1.05);
  // this.scene.add(outlineMesh1);
  // this.render();
};

SceneController.prototype.envMap = function() {
  if (this.params.envMapping) {
    this.scene.remove(this.mesh);

    var textureLoader = new THREE.TextureLoader();
    var textureEquirec = textureLoader.load("./js/textures/indoor2.jpg");
    textureEquirec.mapping = THREE.EquirectangularReflectionMapping;
    textureEquirec.magFilter = THREE.LinearFilter;
    textureEquirec.minFilter = THREE.LinearMipMapLinearFilter;
    textureEquirec.encoding = THREE.sRGBEncoding;

    //Load sphere marial and set values
    var textureSphere = textureLoader.load("./js/textures/metal.jpg");
    textureSphere.mapping = THREE.SphericalReflectionMapping;
    textureSphere.encoding = THREE.sRGBEncoding;

    //Load shader from the library shderLib
    var equirectShader = THREE.ShaderLib["equirect"];

    var equirectMaterial = new THREE.ShaderMaterial({
      fragmentShader: equirectShader.fragmentShader,
      vertexShader: equirectShader.vertexShader,
      uniforms: equirectShader.uniforms,
      depthWrite: false,
      side: THREE.BackSide
    });
    equirectMaterial.uniforms["tEquirect"].value = textureEquirec;
    // enable code injection for non-built-in material
    Object.defineProperty(equirectMaterial, "map", {
      get: function() {
        return this.uniforms.tEquirect.value;
      }
    });
    var cubeShader = THREE.ShaderLib["cube"];
    var cubeMaterial = new THREE.ShaderMaterial({
      fragmentShader: cubeShader.fragmentShader,
      vertexShader: cubeShader.vertexShader,
      uniforms: cubeShader.uniforms,
      depthWrite: false,
      side: THREE.BackSide
    });
    cubeMaterial.uniforms["tCube"].value = textureEquirec;
    Object.defineProperty(cubeMaterial, "map", {
      get: function() {
        return this.uniforms.tCube.value;
      }
    });
    //Size of the box geomerty, decides how close/far the background will loook like
    cubeMesh = new THREE.Mesh(
      new THREE.BoxBufferGeometry(3, 3, 3),
      textureEquirec
    );
    //Geometry here doesn't really matter, since I call this.changeModel later on
    var geometry = new THREE.SphereBufferGeometry(400.0, 48, 24);
    var sphereMaterial = new THREE.MeshLambertMaterial({
      envMap: textureEquirec
    });
    this.mesh = new THREE.Mesh(geometry, sphereMaterial);

    cubeMesh.material = equirectMaterial;
    cubeMesh.visible = true;
    //The reflection sphere
    sphereMaterial.envMap = textureEquirec;
    sphereMaterial.needsUpdate = true;

    this.scene.add(this.mesh);
    this.scene.add(cubeMesh);

    //Otherwise everything is dark
    this.renderer.gammaOutput = true;
    //Update right model
    this.params.model = "sphere";
    this.changeModel();
    //Load texture on the left
    this.saveOldTex = this.params.texImg;
    this.params.texImg = "indoor2";
    this.changeTexture();
    ////
  } else {
    //Regular shader
    this.scene.remove(cubeMesh);
    this.params.texImg = this.saveOldTex;
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShader").textContent,
      fragmentShader: document.getElementById("fragmentShader").textContent
    });
    this.mesh.material = this.material;
    this.changeTexture();
  }
  this.render();
};

SceneController.prototype.bumpMap = function() {
  // console.log(this.params.bumpMap);
  if (this.params.bumpMap) {
    var textureLoader = new THREE.TextureLoader();
    var textureEquirec = textureLoader.load("./js/textures/wood_bump.jpg");
    var texture = textureLoader.load(`./js/textures/${this.params.texImg}.jpg`);

    var BumpMapMaterial = new THREE.MeshPhongMaterial({
      shininess: 20,
      bumpMap: textureEquirec,
      map: texture,
      bumpScale: 0.45
    });

    this.mesh.material = BumpMapMaterial;
    this.mesh.material.needsUpdate = true;
  } else {
    this.changeTexture();
  }
};

SceneController.prototype.fixSphericalMap = function() {
  if (this.params.fixSMapping) {
    //Spherical shader
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShaderSphere").textContent,
      fragmentShader: document.getElementById("fragmentShaderSphere")
        .textContent
    });
  } else {
    //Regular shader
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShader").textContent,
      fragmentShader: document.getElementById("fragmentShader").textContent
    });
  }

  this.mesh.material = this.material;

  this.render();
  this.render();
};

SceneController.prototype.penDrawing = function() {
  if (this.params.pen) {
    this.drawingCanvas = document.createElement("canvas");
    console.log(this.drawingCanvas);

    // might need to uncomment the multiplication
    // if you know what's happening here, please let me know
    this.drawingCanvas.height = this.textureCanvas.height * 0.5;
    this.drawingCanvas.width = this.textureCanvas.width * 0.5;

    this.drawingCanvas.setAttribute(
      "style",
      "position: absolute; top: 0; left: 0;"
    );
    document.body.appendChild(this.drawingCanvas);
    //Html element
    this.drawingCanvasContext = this.drawingCanvas.getContext("2d");

    this.drawingCanvas.addEventListener(
      "mousemove",
      function(e) {
        e.preventDefault();
        this.draw("move", e);
      }.bind(this),
      false
    );

    this.drawingCanvas.addEventListener(
      "mousedown",
      function(e) {
        this.draw("down", e);
      }.bind(this),
      false
    );

    this.drawingCanvas.addEventListener(
      "mouseup",
      function(e) {
        this.draw("up", e);
      }.bind(this),
      false
    );

    this.drawingCanvas.addEventListener(
      "mouseout",
      function(e) {
        this.draw("out", e);
      }.bind(this),
      false
    );
  } else {
    document.body.removeChild(this.drawingCanvas);
    //Todo: update texture

    // this.changeTexture();
    //Regular shader
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      vertexShader: document.getElementById("vertexShader").textContent,
      fragmentShader: document.getElementById("fragmentShader").textContent
    });

    this.mesh.material.needsUpdate = true;
    this.changeTexture();
  }
};

SceneController.prototype.draw = function(res, e) {
  // https://stackoverflow.com/questions/2368784/draw-on-html5-canvas-using-a-mouse
  if (res == "down") {
    this.prevX = this.currX;
    this.prevY = this.currY;
    this.currX = e.clientX - this.drawingCanvas.offsetLeft;
    this.currY = e.clientY - this.drawingCanvas.offsetTop;

    this.flag = true;
    this.dot_flag = true;

    if (this.dot_flag) {
      this.drawingCanvasContext.beginPath();
      this.drawingCanvasContext.fillStyle = "white";
      this.drawingCanvasContext.fillRect(this.currX, this.currY, 2, 2);
      this.drawingCanvasContext.closePath();
      this.dot_flag = false;
    }
  }

  if (res == "up" || res == "out") {
    this.flag = false;
  }
  if (res == "move") {
    if (this.flag) {
      this.prevX = this.currX;
      this.prevY = this.currY;
      this.currX = e.clientX - this.drawingCanvas.offsetLeft;
      this.currY = e.clientY - this.drawingCanvas.offsetTop;
      this.makeStroke();
    }
  }
};

SceneController.prototype.makeStroke = function() {
  this.drawingCanvasContext.beginPath();
  this.drawingCanvasContext.moveTo(this.prevX, this.prevY);
  this.drawingCanvasContext.lineTo(this.currX, this.currY);
  this.drawingCanvasContext.strokeStyle = "orange";
  this.drawingCanvasContext.lineWidth = 2;
  this.drawingCanvasContext.stroke();
  this.drawingCanvasContext.closePath();

  //Creates a new texture for canvas
  this.textureCanvas2 = new THREE.CanvasTexture(this.drawingCanvas);
  //Add the canvas to uniforms
  this.uniforms = {
    texture: { type: "sampler2D", value: this.texture },
    texture2: { type: "sampler2D", value: this.textureCanvas2 },
    viewVector: { type: "vec3", value: this.camera.position }
  };
  this.texture.needsUpdate = true; // important
  this.textureCanvas2.needsUpdate = true; // important

  //Use the new vertex and fragment shader, that will merge both of the textures
  this.material = new THREE.ShaderMaterial({
    uniforms: this.uniforms,
    vertexShader: document.getElementById("vertexShaderBlend").textContent,
    fragmentShader: document.getElementById("fragmentShaderBlend").textContent
  });

  this.mesh.material = this.material;
  this.mesh.material.needsUpdate = true;

  this.render();
};

SceneController.prototype.setupGeometry = function() {
  this.texture = new THREE.TextureLoader().load("./js/textures/earth.jpg");
  this.uniforms = {
    texture: { type: "sampler2D", value: this.texture },
    texture2: { type: "sampler2D", value: this.drawingCanvas },
    viewVector: { type: "vec3", value: this.camera.position }
  };
  this.vertShader = document.getElementById("vertexShader").innerHTML;
  this.fragShader = document.getElementById("fragmentShader").innerHTML;

  this.geometry = new THREE.PlaneBufferGeometry(0.5, 0.5);
  //var material = new THREE.MeshLambertMaterial({ color: "blue" });

  this.material = new THREE.ShaderMaterial({
    uniforms: this.uniforms,
    vertexShader: document.getElementById("vertexShader").textContent,
    fragmentShader: document.getElementById("fragmentShader").textContent
  });

  // Render object in wireframe for debugging
  // var material = new THREE.MeshLambertMaterial( { color: "blue", wireframe: true} );
  this.mesh = new THREE.Mesh(this.geometry, this.material);
  this.scene.add(this.mesh);

  // immediately use the texture for material creation
  this.material2 = new THREE.MeshBasicMaterial({ map: this.texture });
  var geometry2 = new THREE.PlaneBufferGeometry(1, 1);
  this.mesh2 = new THREE.Mesh(geometry2, this.material2);

  this.texScene.add(this.mesh2);
};

SceneController.prototype.setupLight = function() {
  var light = new THREE.PointLight(0xffffcc, 1, 100);
  light.position.set(10, 30, 15);
  this.texScene.add(light);
  this.scene.add(light);

  var light2 = new THREE.PointLight(0xffffcc, 1, 100);
  light2.position.set(10, -30, -15);
  this.texScene.add(light2);
  this.scene.add(light2);

  this.texScene.add(new THREE.AmbientLight(0x999999));
  this.scene.add(new THREE.AmbientLight(0x999999));
};

SceneController.prototype.render = function() {
  this.camera.lookAt(this.scene.position);

  this.texRenderer.render(this.texScene, this.texCamera);
  this.renderer.render(this.scene, this.camera);
  this.stats.update();
};

SceneController.prototype.animate = function() {
  requestAnimationFrame(this.animate.bind(this));
  this.stats.update();
  this.controls.update();
  this.render();
};
