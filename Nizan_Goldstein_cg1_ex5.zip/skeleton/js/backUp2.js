function dataSetColor(self, x, y, color, alpha = 1) {
  let index = x + y * self.width;
  self.data[index * 4] = color.r * 255;
  self.data[index * 4 + 1] = color.g * 255.0;
  self.data[index * 4 + 2] = color.b * 255.0;
  self.data[index * 4 + 3] = alpha * 255;
}

ImageData.prototype.setColor = function(x, y, color, alpha = 1) {
  dataSetColor(this, x, y, color, alpha);
};

function dataReadColor(self, x, y, color) {
  let index = x + y * self.width;
  color.r = self.data[index * 4] / 255;
  color.g = self.data[index * 4 + 1] / 255.0;
  color.b = self.data[index * 4 + 2] / 255.0;
  return self.data[index * 4 + 3] / 255.0;
}

ImageData.prototype.readColor = function(x, y, color) {
  return dataReadColor(this, x, y, color);
};

function createImageData(width, height) {
  let data = [];
  for (var i = 0; i < width * height; i += 1) {
    data.push(0);
    data.push(0);
    data.push(0);
    data.push(0);
  }
  let obj = {
    width: width,
    height: height,
    data: data
  };
  Object.defineProperty(obj, "setColor", {
    value: ImageData.prototype.setColor
  });
  Object.defineProperty(obj, "readColor", {
    value: ImageData.prototype.readColor
  });
  return obj;
}

/**
 * RaytracingRenderer interpretation of http://github.com/zz85
 */

var RaytracingRenderer = function(scene, camera, workerObject) {
  this.print = true;
  this.scene = scene;
  this.camera = camera;

  this.rendering = false;
  this.superSamplingRate = 0;
  this.maxRecursionDepth = 2;

  this.allLights = true;
  this.calcDiffuse = true;
  this.calcPhong = true;
  this.phongMagnitude = 10;
  this.useMirrors = true;

  this.workerObject = workerObject;
  this.isWorker = workerObject != undefined;

  if (!this.isWorker) {
    this.canvas = document.createElement("canvas");
    window.canvas = this.canvas;
    this.context = this.canvas.getContext("2d", {
      alpha: false
    });

    this.createImageData = this.context.createImageData.bind(this.context);
  } else {
    this.createImageData = createImageData;
  }
  this.workerCount = 4;
  this.sectionWidth = 6;
  this.sectionSize = { x: 64, y: 64 };

  this.overwriteSize = false;
  this.sizeOverwrite = { x: 320, y: 320 };

  this.clearColor = new THREE.Color(0x000000);
  this.domElement = this.canvas;
  this.autoClear = true;

  this.raycaster = new THREE.Raycaster();
  this.imageData = null;
  if (typeof Image != "undefined") {
    this.image = new Image();
    this.image.onload = this.render.bind(this);
  }

  if (!this.isWorker) {
    this.clock = new THREE.Clock();
    this.workers = [];
    this.tmpColor = new THREE.Color(0, 0, 0);

    setInterval(this.updateWorkers.bind(this), 1000);
  }

  this.lights = [];
  for (var c = 0; c < this.scene.children.length; c++) {
    if (this.scene.children[c].isPointLight)
      this.lights.push(this.scene.children[c]);
  }
};

RaytracingRenderer.prototype.setClearColor = function(color, alpha) {
  clearColor.set(color);
};

RaytracingRenderer.prototype.clear = function() {};

RaytracingRenderer.prototype.spawnWorker = function() {
  var worker = new Worker("js/worker.js");
  worker.addEventListener(
    "message",
    this.workerMessageHandler.bind(this),
    false
  );
  this.workers.push(worker);
};

RaytracingRenderer.prototype.workerMessageHandler = function(e) {
  switch (e.data.message) {
    case "raytraceResult":
      let sectionWidth = e.data.data.width;
      let sectionHeight = e.data.data.height;
      for (let y = 0; y < sectionHeight; y += 1) {
        for (let x = 0; x < sectionWidth; x += 1) {
          dataReadColor(e.data.data, x, y, this.tmpColor);
          this.imageData.setColor(x, y, this.tmpColor);
        }
      }
      this.context.putImageData(this.imageData, e.data.startX, e.data.startY);
      this.render();
      this.sectionCount.calculated += 1;
      if (this.sectionCount.calculated == this.sectionCount.total) {
        this.rendering = false;
        this.clock.stop();
        console.log(
          "Finished rendering in " +
            this.clock.elapsedTime +
            " seconds. Image " +
            this.canvas.width +
            " w / " +
            this.canvas.height +
            " h"
        );
      }
      break;
  }
};

RaytracingRenderer.prototype.render = function() {
  if (this.imageData != null) {
    let imageAspect = this.canvas.width / this.canvas.height;
    if (imageAspect < window.innerWidth / window.innerHeight) {
      let width = window.innerHeight * imageAspect;
      this.canvas.style.width = width + "px";
      this.canvas.style.height = "100%";
      this.canvas.style.left = (window.innerWidth - width) / 2 + "px";
      this.canvas.style.top = "0px";
    } else {
      let height = window.innerWidth / imageAspect;
      this.canvas.style.width = "100%";
      this.canvas.style.height = height + "px";
      this.canvas.style.left = "0px";
      this.canvas.style.top = (window.innerHeight - height) / 2 + "px";
    }
  }
};

RaytracingRenderer.prototype.saveImage = function() {
  this.canvas.toBlob(function(blob) {
    saveAs(blob, "img.png");
  }, "./");
};

RaytracingRenderer.prototype.updateWorkers = function() {
  this.workerCount = Math.max(Math.floor(this.workerCount), 1);
  while (this.workers.length < this.workerCount) {
    this.spawnWorker();
  }
  if (this.workers.length > this.workerCount) {
    for (let i = this.workerCount; i < this.workers.length; i += 1) {
      this.workers[i].postMessage({ command: "close" });
    }
    this.workers.splice(
      this.workerCount,
      this.workers.length - this.workerCount
    );
  }
};

RaytracingRenderer.prototype.raytrace = function() {
  if (!this.rendering) {
    let width;
    let height;
    if (this.isWorker || this.overwriteSize) {
      width = this.sizeOverwrite.x;
      height = this.sizeOverwrite.y;
    } else {
      width = window.innerWidth;
      height = window.innerHeight;
    }
    this.sectionCount = {};
    if (!this.isWorker) {
      this.sectionSize = { x: Math.pow(2, this.sectionWidth) };
      this.sectionSize.y = this.sectionSize.x;
    }
    this.sectionCount.x = Math.ceil(width / this.sectionSize.x); //Ceil Rounds the numbe r
    this.sectionCount.y = Math.ceil(width / this.sectionSize.y);
    this.sectionCount.total = this.sectionCount.x * this.sectionCount.y;
    this.sectionCount.calculated = 0;
    if (!this.isWorker) {
      this.imageData = this.createImageData(
        this.sectionSize.x,
        this.sectionSize.y
      );
      this.updateWorkers();
      this.clock.start();
      this.rendering = true;
      this.canvas.width = width;
      this.canvas.height = height;
      this.workerProgress = [];
      this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
      for (let i = 0; i < this.workers.length; i += 1) {
        this.workerProgress.push(0);
        let worker = this.workers[i];
        worker.postMessage({
          command: "raytrace",
          size: { x: width, y: height },
          superSamplingRate: this.superSamplingRate,
          maxRecursionDepth: this.maxRecursionDepth,
          phongMagnitude: this.phongMagnitude,
          allLights: this.allLights,
          calcDiffuse: this.calcDiffuse,
          calcPhong: this.calcPhong,
          useMirrors: this.useMirrors,
          sectionSize: this.sectionSize,
          workerIndex: i,
          workerCount: this.workers.length
        });
      }
    } else {
      // update scene graph
      if (this.scene.autoUpdate === true) {
        this.scene.updateMatrixWorld();
      }

      // update camera matrices
      if (this.camera.parent === null) {
        this.camera.updateMatrixWorld();
      }

      this.camera.aspect = width / height;
      this.camera.updateProjectionMatrix();

      for (
        let i = this.workerIndex;
        i < this.sectionCount.total;
        i += this.workerCount
      ) {
        let x = (i % this.sectionCount.x) * this.sectionSize.x;
        let y = Math.floor(i / this.sectionCount.x) * this.sectionSize.y;

        this.fillImageWithNoisyStripes(
          x,
          y,
          this.sectionSize.x,
          this.sectionSize.y,
          width,
          height
        );
        //-----------Testing--------------
        // var raycaster = new THREE.Raycaster();
        // raycaster.setFromCamera(1, this.camera);
        // console.log(raycaster.params);
        //--------------------------------

        this.raytraceSection(
          x,
          y,
          this.sectionSize.x,
          this.sectionSize.y,
          width,
          height
        );
      }

      this.rendering = false;
    }
  }
};

RaytracingRenderer.prototype.fillImageWithNoisyStripes = function(
  startX,
  startY,
  width,
  height,
  totalWidth,
  totalHeight
) {
  //fill image with noise
  this.imageData = this.createImageData(width, height);

  for (let y = startY; y < startY + height; y += 1) {
    let c = new THREE.Color(Math.random(), Math.random(), Math.random());
    for (let x = startX; x < startX + width; x += 1) {
      this.imageData.setColor(x - startX, y - startY, c);
    }
  }

  if (!this.isWorker) {
    this.canvas.width = width;
    this.canvas.height = height;
    this.context.putImageData(this.imageData, 0, 0);
    this.image.src = this.canvas.toDataURL();
  } else {
    this.workerObject.postMessage({
      message: "raytraceResult",
      data: this.imageData,
      startX: startX,
      startY: startY
    });
  }
};

RaytracingRenderer.prototype.raytraceSection = function(
  startX,
  startY,
  width,
  height,
  totalWidth,
  totalHeight
) {
  this.imageData = this.createImageData(width, height);

  let defaultColor = new THREE.Color(0, 0, 0);
  let screenPos = new THREE.Vector2(0, 0);
  let pixelColor = new THREE.Color(0, 0, 0);

  for (let y = startY; y < startY + height; y += 1) {
    for (let x = startX; x < startX + width; x += 1) {
      pixelColor.setRGB(0, 0, 0);

      if (this.superSamplingRate < 1) {
        let castX = (x / totalWidth) * 2 - 1;
        let castY = (y / totalHeight) * 2 - 1;
        this.renderPixel(
          pixelColor,
          screenPos.set(castX, -castY),
          defaultColor
        );
      } else {
        // Todo: super-sampling
      }
      this.imageData.setColor(x - startX, y - startY, pixelColor);
    }
  }

  if (!this.isWorker) {
    this.canvas.width = width;
    this.canvas.height = height;
    this.context.putImageData(this.imageData, 0, 0);
    this.image.src = this.canvas.toDataURL();
  } else {
    this.workerObject.postMessage({
      message: "raytraceResult",
      data: this.imageData,
      startX: startX,
      startY: startY
    });
  }
};

RaytracingRenderer.prototype.renderPixel = function(
  pixelColor,
  pixPos,
  defaultColor
) {
  //Try---------------------
  this.raycaster = new THREE.Raycaster();
  this.raycaster.setFromCamera(pixPos, this.camera);
  //   raycaster.setFromCamera(pixPos, this.camera);
  //   console.log(raycaster);

  //------------------------
  // Todo: compute çamera position and ray direction

  let cameraPos = new THREE.Vector3();
  cameraPos = this.camera.position;

  let direction = new THREE.Vector3();
  direction = this.raycaster.ray.direction;

  return this.spawnRay(
    pixelColor,
    cameraPos,
    direction,
    this.maxRecursionDepth,
    Infinity,
    defaultColor
  );
};

RaytracingRenderer.prototype.getIntersection = function(
  origin,
  direction,
  farPlane
) {
  var intersects = this.raycaster.intersectObjects(this.scene.children);
  if (intersects.length > 0) {
    let intersections = intersects[0];

    return intersections;
  } else return null;
};

//this method has most of the stuff of this exercise.
//good coding style will ease this exercise significantly.
RaytracingRenderer.prototype.spawnRay = function(
  pixelColor,
  origin,
  direction,
  recursionDepth,
  farPlane,
  defaultColor
) {
  this.objects = this.scene.children;
  // calculate objects intersecting the picking ray
  let intersection = this.getIntersection(origin, direction, farPlane);

  if (intersection != null) {
    // ToDo: compute color, if material is mirror, spawnRay again

    this.calculateLightColor(pixelColor, origin, intersection, recursionDepth);

    // //Assigment 1
    // let Material = intersection.material;
    // let color = Material.color;
    // pixelColor.set(color);
    return true;
  } else {
    pixelColor.set(defaultColor);
    return false;
  }
};

RaytracingRenderer.prototype.calculateLightColor = function(
  pixelColor,
  origin,
  intersection,
  recursionDepth
) {
  var lightColor = new THREE.Color();
  let diffuseColor = new THREE.Color();
  let ambientColor = new THREE.Color();
  // diffuseColor.copyGammaToLinear(material.color);
  let specColor = new THREE.Color();

  var eyeVector = new THREE.Vector3();
  var normal = new THREE.Vector3();

  var raycasterLight = new THREE.Raycaster();
  var rayLight = raycasterLight.ray;

  var lightContribution = new THREE.Color();

  var point = intersection.point;
  var object = intersection.object;
  var material = object.material;
  var face = intersection.face;

  var geometry = object.geometry;

  var color = new THREE.Color(1, 0, 0);
  // ToDo: compute pixel color
  // notes: need normal vector, light direction (e.g. lightDir.setFromMatrixPosition(light.matrixWorld);)
  // if not in the shadow, compute color based on phong model
  //The Raycaster sebds out a vektor and lists basically all the objects in order appereance
  //----------------------------------Trying
  rayLight.origin.copy(point);
  let lightDir = new THREE.Vector3();
  lightDir.setFromMatrixPosition(this.lights[2].matrixWorld);
  lightDir.sub(point);
  //To check if in the shadow
  rayLight.direction.copy(lightDir).normalize();

  var intersections = raycasterLight.intersectObject(object);

  //Eye Vektor
  eyeVector.subVectors(origin, point).normalize();

  let isInShadow = intersections.length > 0;
  if (object.geometry.type == "BoxGeometry") {
    normal = face.normal;
  } else if (object.geometry.type == "SphereGeometry") {
    normal.subVectors(point, object.position).normalize();
  } else {
    color = setRGB(0, 0, 1);
  }
  //Diffuse
  if (
    material.isMeshLambertMaterial ||
    material.isMeshPhongMaterial ||
    material.isMeshBasicMaterial
  ) {
    diffuseColor.copyGammaToLinear(material.color);
  } else {
    diffuseColor.setRGB(1, 1, 1);
  }
  if (material.vertexColors === THREE.FaceColors) {
    diffuseColor.multiply(face.color);
  }

  //
  if (!isInShadow) {
    // // console.log(object.geometry.type);
    // let magnitude = 2;
    // let ambientColor = new THREE.Color(0.1, 0.1, 0.1);
    // diffuseColor.copyGammaToLinear(material.color);
    // let specColor = new THREE.Color(0.5, 0.5, 0.5);

    // //For a given incident vector I =  and surface normal N - lightDirection normal1 .reflect returns the reflection direction calculated as I - 2.0 * dot(N, I) * N.        N should be normalized in order to achieve the desired result.
    // let reflectDirection = normal.reflect(-lightDir);
    // //Takes only positive dot
    // let lambertian = Math.max(lightDir.dot(normal), 0.0);
    // let specular = 0.0;

    // if (lambertian > 0.0) {
    //   let specAngle = max(reflectDirection.dot(eyeVector), 0.0);
    //   specular = pow(specAngle, magnitude * 16.0 + 0.0000000001);
    // }

    // color.setRGB(
    //   ambientColor.x + lambertian * diffuseColor.x + specular * specColor.x,
    //   ambientColor.y + lambertian * diffuseColor.y + specular * specColor.y,
    //   ambientColor.z + lambertian * diffuseColor.z + specular * specColor.z
    // );
    if (material.isMeshBasicMaterial) {
      color.add(diffuseColor);
    } else if (material.isMeshLambertMaterial || material.isMeshPhongMaterial) {
      lightColor.copyGammaToLinear(this.lights[2].color);
      var attenuation = 1.0;
      if (this.lights[2].physicalAttenuation === true) {
        attenuation = lightDir.length();
        attenuation = 1.0 / (attenuation * attenuation);
      }
      var dot = Math.max(normal.dot(lightDir), 0);
      var diffuseIntensity = dot * this.lights[2].intensity;
      lightContribution.copy(diffuseColor);
      lightContribution.multiply(lightColor);
      lightContribution.multiplyScalar(diffuseIntensity * attenuation);
      color.add(lightContribution);
    }
  } else {
    color.set(0, 0, 0);
  }
  // color.setRGB(0, 1, 0);
  pixelColor.set(color);
};

// rayLight.origin.copy(point);
// compute light shading

//----------------------------------
//Need to update after I get the pgong values
// let color = material.color;
// pixelColor.set(color);

/*

* Getting the Normal :
*intersection.point and intersection.face are both needed
* if you use intersection.face you get spheres which aren't smoothed which is fine if you want to show the actual 3D shade
* *shape
* BUT
* We don't
* So for the cubes / planes you take the intersection.face.normal
* and for the spheres you take the intersection.point-intersection.object.position and normalize it
* here if you just take the normals though you'll wonder why it doesn't look quite right. so you need to apply the objects.quaternion aswell to the normal
* that way you get the right orientation
* That's for the normals
* ///////--------------------------------------------------///
* To get the shadow ray you simple throw a ray from the intersection point towards the light
* if there is intersections the point is in shadow
* diffuse is still the same. normal angle to the lightsource
* phong too
* reflected angle to the camera
* there is three.js functions which make do a bunch of it for you
*/

/*

  //normal
  // var normals = geometry.attributes.normal;
  // console.log(normals);

  let ambientColor = new THREE.Vector3(0.3, 0.0, 0.0);
  let diffuseColor = new THREE.Vector3(0.5, 0.0, 0.0);
  let specColor = new THREE.Vector3(0.5, 0.5, 0.5);

  //For a given incident vector I =  and surface normal N - lightDirection normal1 .reflect returns the reflection direction calculated as I - 2.0 * dot(N, I) * N.        N should be normalized in order to achieve the desired result.
  let reflectDirection = face.normal.reflect(-lightDir);
  origin = origin.normalize();
  //Takes only positive dot
  let lambertian = Math.max(lightDir.dot(face.normal), 0.0);
  let specular = 0.0;

  if (lambertian > 0.0) {
    let specAngle = max(reflectDirection.dot(origin), 0.0);
    specular = pow(specAngle, magnitude * 16.0 + 0.0000000001);
  }

  color = (ambientColor.x +
    lambertian * diffuseColor.x +
    specular * specColor.x,
  ambientColor.y + lambertian * diffuseColor.y + specular * specColor.y,
  ambientColor.z + lambertian * diffuseColor.z + specular * specColor.z);

*/
