function dataSetColor(self, x, y, color, alpha = 1) {
  let index = x + y * self.width;
  self.data[index * 4] = color.r * 255;
  self.data[index * 4 + 1] = color.g * 255.0;
  self.data[index * 4 + 2] = color.b * 255.0;
  self.data[index * 4 + 3] = alpha * 255;
}

ImageData.prototype.setColor = function(x, y, color, alpha = 1) {
  dataSetColor(this, x, y, color, alpha);
};

function dataReadColor(self, x, y, color) {
  let index = x + y * self.width;
  color.r = self.data[index * 4] / 255;
  color.g = self.data[index * 4 + 1] / 255.0;
  color.b = self.data[index * 4 + 2] / 255.0;
  return self.data[index * 4 + 3] / 255.0;
}

ImageData.prototype.readColor = function(x, y, color) {
  return dataReadColor(this, x, y, color);
};

function createImageData(width, height) {
  let data = [];
  for (var i = 0; i < width * height; i += 1) {
    data.push(0);
    data.push(0);
    data.push(0);
    data.push(0);
  }
  let obj = {
    width: width,
    height: height,
    data: data
  };
  Object.defineProperty(obj, "setColor", {
    value: ImageData.prototype.setColor
  });
  Object.defineProperty(obj, "readColor", {
    value: ImageData.prototype.readColor
  });
  return obj;
}

/**
 * RaytracingRenderer interpretation of http://github.com/zz85
 */

var RaytracingRenderer = function(scene, camera, workerObject) {
  this.print = 0;
  this.scene = scene;
  this.camera = camera;

  this.rendering = false;
  this.superSamplingRate = 0;
  this.maxRecursionDepth = 3;

  this.allLights = true;
  this.calcDiffuse = true;
  this.calcPhong = true;
  this.phongMagnitude = 10;
  this.useMirrors = true;

  this.workerObject = workerObject;
  this.isWorker = workerObject != undefined;

  if (!this.isWorker) {
    this.canvas = document.createElement("canvas");
    window.canvas = this.canvas;
    this.context = this.canvas.getContext("2d", {
      alpha: false
    });

    this.createImageData = this.context.createImageData.bind(this.context);
  } else {
    this.createImageData = createImageData;
  }
  this.workerCount = 4;
  this.sectionWidth = 6;
  this.sectionSize = { x: 64, y: 64 };

  this.overwriteSize = false;
  this.sizeOverwrite = { x: 320, y: 320 };

  this.clearColor = new THREE.Color(0x000000);
  this.domElement = this.canvas;
  this.autoClear = true;

  this.raycaster = new THREE.Raycaster();
  this.imageData = null;
  if (typeof Image != "undefined") {
    this.image = new Image();
    this.image.onload = this.render.bind(this);
  }

  if (!this.isWorker) {
    this.clock = new THREE.Clock();
    this.workers = [];
    this.tmpColor = new THREE.Color(0, 0, 0);

    setInterval(this.updateWorkers.bind(this), 1000);
  }

  this.lights = [];
  for (var c = 0; c < this.scene.children.length; c++) {
    if (this.scene.children[c].isPointLight)
      this.lights.push(this.scene.children[c]);
  }
};

RaytracingRenderer.prototype.setClearColor = function(color, alpha) {
  clearColor.set(color);
};

RaytracingRenderer.prototype.clear = function() {};

RaytracingRenderer.prototype.spawnWorker = function() {
  var worker = new Worker("js/worker.js");
  worker.addEventListener(
    "message",
    this.workerMessageHandler.bind(this),
    false
  );
  this.workers.push(worker);
};

RaytracingRenderer.prototype.workerMessageHandler = function(e) {
  switch (e.data.message) {
    case "raytraceResult":
      let sectionWidth = e.data.data.width;
      let sectionHeight = e.data.data.height;
      for (let y = 0; y < sectionHeight; y += 1) {
        for (let x = 0; x < sectionWidth; x += 1) {
          dataReadColor(e.data.data, x, y, this.tmpColor);
          this.imageData.setColor(x, y, this.tmpColor);
        }
      }
      this.context.putImageData(this.imageData, e.data.startX, e.data.startY);
      this.render();
      this.sectionCount.calculated += 1;
      if (this.sectionCount.calculated == this.sectionCount.total) {
        this.rendering = false;
        this.clock.stop();
        console.log(
          "Finished rendering in " +
            this.clock.elapsedTime +
            " seconds. Image " +
            this.canvas.width +
            " w / " +
            this.canvas.height +
            " h"
        );
      }
      break;
  }
};

RaytracingRenderer.prototype.render = function() {
  if (this.imageData != null) {
    let imageAspect = this.canvas.width / this.canvas.height;
    if (imageAspect < window.innerWidth / window.innerHeight) {
      let width = window.innerHeight * imageAspect;
      this.canvas.style.width = width + "px";
      this.canvas.style.height = "100%";
      this.canvas.style.left = (window.innerWidth - width) / 2 + "px";
      this.canvas.style.top = "0px";
    } else {
      let height = window.innerWidth / imageAspect;
      this.canvas.style.width = "100%";
      this.canvas.style.height = height + "px";
      this.canvas.style.left = "0px";
      this.canvas.style.top = (window.innerHeight - height) / 2 + "px";
    }
  }
};

RaytracingRenderer.prototype.saveImage = function() {
  this.canvas.toBlob(function(blob) {
    saveAs(blob, "img.png");
  }, "./");
};

RaytracingRenderer.prototype.updateWorkers = function() {
  this.workerCount = Math.max(Math.floor(this.workerCount), 1);
  while (this.workers.length < this.workerCount) {
    this.spawnWorker();
  }
  if (this.workers.length > this.workerCount) {
    for (let i = this.workerCount; i < this.workers.length; i += 1) {
      this.workers[i].postMessage({ command: "close" });
    }
    this.workers.splice(
      this.workerCount,
      this.workers.length - this.workerCount
    );
  }
};

RaytracingRenderer.prototype.raytrace = function() {
  if (!this.rendering) {
    let width;
    let height;
    if (this.isWorker || this.overwriteSize) {
      width = this.sizeOverwrite.x;
      height = this.sizeOverwrite.y;
    } else {
      width = window.innerWidth;
      height = window.innerHeight;
    }
    this.sectionCount = {};
    if (!this.isWorker) {
      this.sectionSize = { x: Math.pow(2, this.sectionWidth) };
      this.sectionSize.y = this.sectionSize.x;
    }
    this.sectionCount.x = Math.ceil(width / this.sectionSize.x); //Ceil Rounds the numbe r
    this.sectionCount.y = Math.ceil(width / this.sectionSize.y);
    this.sectionCount.total = this.sectionCount.x * this.sectionCount.y;
    this.sectionCount.calculated = 0;
    if (!this.isWorker) {
      this.imageData = this.createImageData(
        this.sectionSize.x,
        this.sectionSize.y
      );
      this.updateWorkers();
      this.clock.start();
      this.rendering = true;
      this.canvas.width = width;
      this.canvas.height = height;
      this.workerProgress = [];
      this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
      for (let i = 0; i < this.workers.length; i += 1) {
        this.workerProgress.push(0);
        let worker = this.workers[i];
        worker.postMessage({
          command: "raytrace",
          size: { x: width, y: height },
          superSamplingRate: this.superSamplingRate,
          maxRecursionDepth: this.maxRecursionDepth,
          phongMagnitude: this.phongMagnitude,
          allLights: this.allLights,
          calcDiffuse: this.calcDiffuse,
          calcPhong: this.calcPhong,
          useMirrors: this.useMirrors,
          sectionSize: this.sectionSize,
          workerIndex: i,
          workerCount: this.workers.length
        });
      }
    } else {
      // update scene graph
      if (this.scene.autoUpdate === true) {
        this.scene.updateMatrixWorld();
      }

      // update camera matrices
      if (this.camera.parent === null) {
        this.camera.updateMatrixWorld();
      }

      this.camera.aspect = width / height;
      this.camera.updateProjectionMatrix();

      for (
        let i = this.workerIndex;
        i < this.sectionCount.total;
        i += this.workerCount
      ) {
        let x = (i % this.sectionCount.x) * this.sectionSize.x;
        let y = Math.floor(i / this.sectionCount.x) * this.sectionSize.y;

        this.fillImageWithNoisyStripes(
          x,
          y,
          this.sectionSize.x,
          this.sectionSize.y,
          width,
          height
        );
        //-----------Testing--------------
        // var raycaster = new THREE.Raycaster();
        // raycaster.setFromCamera(1, this.camera);
        // console.log(raycaster.params);
        //--------------------------------

        this.raytraceSection(
          x,
          y,
          this.sectionSize.x,
          this.sectionSize.y,
          width,
          height
        );
      }

      this.rendering = false;
    }
  }
};

RaytracingRenderer.prototype.fillImageWithNoisyStripes = function(
  startX,
  startY,
  width,
  height,
  totalWidth,
  totalHeight
) {
  //fill image with noise
  this.imageData = this.createImageData(width, height);

  for (let y = startY; y < startY + height; y += 1) {
    let c = new THREE.Color(Math.random(), Math.random(), Math.random());
    for (let x = startX; x < startX + width; x += 1) {
      this.imageData.setColor(x - startX, y - startY, c);
    }
  }

  if (!this.isWorker) {
    this.canvas.width = width;
    this.canvas.height = height;
    this.context.putImageData(this.imageData, 0, 0);
    this.image.src = this.canvas.toDataURL();
  } else {
    this.workerObject.postMessage({
      message: "raytraceResult",
      data: this.imageData,
      startX: startX,
      startY: startY
    });
  }
};

RaytracingRenderer.prototype.raytraceSection = function(
  startX,
  startY,
  width,
  height,
  totalWidth,
  totalHeight
) {
  this.imageData = this.createImageData(width, height);

  let defaultColor = new THREE.Color(0, 0, 0);
  let screenPos = new THREE.Vector2(0, 0);
  let pixelColor = new THREE.Color(0, 0, 0);

  for (let y = startY; y < startY + height; y += 1) {
    for (let x = startX; x < startX + width; x += 1) {
      pixelColor.setRGB(0, 0, 0);

      if (this.superSamplingRate < 1) {
        let castX = (x / totalWidth) * 2 - 1;
        let castY = (y / totalHeight) * 2 - 1;
        this.renderPixel(
          pixelColor,
          screenPos.set(castX, -castY),
          defaultColor
        );
        this.imageData.setColor(x - startX, y - startY, pixelColor);
      } else {
        // let x = 1 / this.superSamplingRate;
        // // let col = new THREE.Color(1, 1, 1);
        // for (let i = 1; i <= this.superSamplingRate; i++) {
        //   let castX = (x / totalWidth) * 2 - 1;
        //   let castY = (y / totalHeight) * 2 - 1;
        //   castX = castX + i * (this.superSamplingRate / 10000);
        //   castY = castY + i * (this.superSamplingRate / 10000);
        //   if (this.print < 1000) {
        //     console.log(`This is castX - ${castX}`);
        //     console.log(`This is castY - ${castY}`);

        //     this.print++;
        //   }
        //Between each potision entering more positions to take value
        for (let i = 1; i <= this.superSamplingRate * 2; i++) {
          let castX = (x / totalWidth) * 2 - 1;
          let castY = (y / totalHeight) * 2 - 1;
          castX =
            castX + (((castX + 1) / this.superSamplingRate) * i) / 100000000;
          castY =
            castY + (((castY + 1) / this.superSamplingRate) * i) / 100000000;
          this.renderPixel(
            pixelColor,
            screenPos.set(castX, -castY),
            defaultColor
          );
          this.imageData.setColor(x - startX, y - startY, pixelColor);
        }
      }
    }
  }

  if (!this.isWorker) {
    this.canvas.width = width;
    this.canvas.height = height;
    this.context.putImageData(this.imageData, 0, 0);
    this.image.src = this.canvas.toDataURL();
  } else {
    this.workerObject.postMessage({
      message: "raytraceResult",
      data: this.imageData,
      startX: startX,
      startY: startY
    });
  }
};

RaytracingRenderer.prototype.renderPixel = function(
  pixelColor,
  pixPos,
  defaultColor
) {
  //Try---------------------
  this.raycaster.setFromCamera(pixPos, this.camera);
  this.ray = this.raycaster.ray;

  //   raycaster.setFromCamera(pixPos, this.camera);
  //   console.log(raycaster);

  //------------------------
  // Todo: compute çamera position and ray direction

  let cameraPos = new THREE.Vector3();
  cameraPos = this.camera.position;

  let direction = new THREE.Vector3();
  direction = this.raycaster.ray.direction;

  return this.spawnRay(
    pixelColor,
    cameraPos,
    direction,
    0,
    Infinity,
    defaultColor
  );
};

RaytracingRenderer.prototype.getIntersection = function(
  origin,
  direction,
  farPlane
) {
  // this.raycaster.set(origin, direction);
  this.ray.origin = origin;
  this.ray.direction = direction;
  this.direction = direction;
  var intersects = this.raycaster.intersectObjects(this.scene.children);
  if (intersects.length > 0) {
    let intersections = intersects[0];
    // if (this.print == this.recursionDepth) {
    //   console.log(intersects[0]);
    //   console.log(this.recursionDepth);
    //   this.print++;
    // }
    return intersections;
  } else return null;
};

//this method has most of the stuff of this exercise.
//good coding style will ease this exercise significantly.
RaytracingRenderer.prototype.spawnRay = function(
  pixelColor,
  origin,
  direction,
  recursionDepth,
  farPlane,
  defaultColor
) {
  // this.recursionDepth = recursionDepth;
  this.objects = this.scene.children;
  // calculate objects intersecting the picking ray

  let intersection = this.getIntersection(origin, direction, farPlane);

  if (intersection != null) {
    // ToDo: compute color, if material is mirror, spawnRay again

    this.calculateLightColor(pixelColor, origin, intersection, recursionDepth);

    // //Assigment 1
    // let Material = intersection.material;
    // let color = Material.color;
    // pixelColor.set(color);
    return true;
  } else {
    pixelColor.set(defaultColor);
    return;
  }
};

RaytracingRenderer.prototype.calculateLightColor = function(
  pixelColor,
  origin,
  intersection,
  recursionDepth
) {
  var point = intersection.point;
  var geometry = intersection.object.geometry;
  var object = intersection.object;
  var material = object.material;

  var lightDir = new THREE.Vector3();
  var eyeVector = new THREE.Vector3();
  var halfVector = new THREE.Vector3();
  var normal = new THREE.Vector3();

  var tmpColor = [];
  for (var i = 0; i < this.maxRecursionDepth; i++) {
    tmpColor[i] = new THREE.Color();
  }

  eyeVector.subVectors(origin, point).normalize();

  //new origin for the light ray is the intersection point
  origin = point;

  //Same calculations to each light on the scene
  for (var i = 0; i < this.lights.length; i++) {
    var light = this.lights[i];

    var lightRaycaster = new THREE.Raycaster();
    var lightRay = lightRaycaster.ray;
    //Checcking if the point is in the shadow or not
    lightRay.origin.copy(origin);
    lightDir.setFromMatrixPosition(light.matrixWorld);
    lightDir.sub(point);

    //To check if in the shadow
    lightRay.direction.copy(lightDir).normalize();
    var intersects = lightRaycaster.intersectObjects(this.scene.children, true);

    //attenuation calculation
    var attenuation = 1.0;
    if (light.physicalAttenuation === true) {
      attenuation = lightDir.length();
      attenuation = 1.0 / (attenuation * attenuation);
    }

    var diffuseColor = new THREE.Color();
    lightDir.normalize();
    diffuseColor.copyGammaToLinear(material.color);
    if (!this.calcPhong && !this.calcDiffuse) {
      pixelColor.set(material.color);
    } else {
      if (intersects.length < 1 && material.isMeshPhongMaterial) {
        //calculate the normal on the intersection face - each geometry different normal
        if (geometry.type === "BoxGeometry") {
          geometry.computeFaceNormals();
          normal = intersection.face.normal;
          //Finally!!!
          normal.applyQuaternion(object.quaternion);
        } else if (geometry.type === "SphereGeometry") {
          //Calculate the normal of the sphere, vektor from the point to the center
          normal.subVectors(point, object.position).normalize();
        }

        var lightContribution = new THREE.Color();

        //diffuse
        var dot = Math.max(normal.dot(lightDir), 0.0);
        var diffuseIntensity = dot * light.intensity;
        lightContribution.copy(diffuseColor);
        lightContribution.multiplyScalar(diffuseIntensity * attenuation);
        // if (this.print < 6000) {
        //   // console.log(lightContribution);
        //   this.print++;
        // }
        if (this.calcDiffuse) {
          pixelColor.add(lightContribution);
        }
        //specular
        halfVector.addVectors(lightDir, eyeVector).normalize();
        var dotNormalHalf = Math.max(normal.dot(halfVector), 0.0);
        var specularIntensity =
          Math.max(Math.pow(dotNormalHalf, material.shininess), 0.0) *
          diffuseIntensity;
        // if (this.print < 6000) {
        //   // console.log(specularIntensity);
        //   this.print++;
        // }
        var specularColor = new THREE.Color();

        var s = (material.shininess + 2.0) / 8.0;
        specularColor.copyGammaToLinear(material.specular);

        if (this.calcPhong) {
          var schlick = new THREE.Color();
          //schlick schlak schlock
          var alpha = Math.pow(
            Math.max(1.0 - lightDir.dot(halfVector), 0.0),
            5.0
          );
          schlick.r = specularColor.r + (1.0 - specularColor.r) * alpha;
          schlick.g = specularColor.g + (1.0 - specularColor.g) * alpha;
          schlick.b = specularColor.b + (1.0 - specularColor.b) * alpha;
          lightContribution.copy(specularColor);
          // lightContribution.copy(schlick);
          lightContribution.multiplyScalar(s * specularIntensity * attenuation);
          // if (this.print < 6000) {
          //   // console.log(lightContribution);
          //   this.print++;
          // }
          pixelColor.add(lightContribution);
        }
        //Calculating only one light!
        if (!this.allLights) {
          break;
        }
      }
    }
  }

  if (this.useMirrors) {
    var reflectionVector = new THREE.Vector3();

    // reflection
    var reflectivity = material.reflectivity;
    // if (material.mirror && this.print < 6000) {
    //   // console.log(reflectivity);
    //   this.print++;
    // }
    if (
      material.mirror &&
      reflectivity > 0 &&
      recursionDepth < this.maxRecursionDepth
    ) {
      reflectionVector.copy(this.direction);
      reflectionVector.reflect(normal);

      var theta = Math.max(eyeVector.dot(normal), 0.0);
      var rf0 = reflectivity;
      // var fresnel = rf0 + (1.0 - rf0) * Math.pow(1.0 - theta, 10);
      var weight = 2 * rf0 * theta;
      var zColor = tmpColor[recursionDepth];
      //rekursin call
      this.spawnRay(zColor, origin, reflectionVector, recursionDepth + 1);
      // if (material.specular !== undefined) {
      //   zColor.multiply(material.specular);
      // }
      // pixelColor.add(zColor);
      // console.log(this.print);
      // this.print++;
      zColor.multiplyScalar(weight);
      zColor.multiplyScalar(weight);
      pixelColor.multiplyScalar(1 - weight);
      // pixelColor.multiplyScalar(1 - weight);
      // if (this.print < 6000 && recursionDepth == 2) {
      //   console.log(zColor);
      //   this.print++;
      // }
      pixelColor.add(zColor);
    }
  }
};
// rayLight.origin.copy(point);
// compute light shading

//----------------------------------
//Need to update after I get the pgong values
// let color = material.color;
// pixelColor.set(color);

/*

* Getting the Normal :
*intersection.point and intersection.face are both needed
* So for the cubes / planes you take the intersection.face.normal + quaternion
* and for the spheres you take the intersection.point-intersection.object.position and normalize it
* shadow ray -  throw a ray from the intersection point towards the light
* if there is intersections the point is in shadow
* diffuse is still the same. normal angle to the lightsource
* phong too
* reflected angle to the camera
*/

/*

  //normal
  // var normals = geometry.attributes.normal;
  // console.log(normals);

  let ambientColor = new THREE.Vector3(0.3, 0.0, 0.0);
  let diffuseColor = new THREE.Vector3(0.5, 0.0, 0.0);
  let specColor = new THREE.Vector3(0.5, 0.5, 0.5);

  //For a given incident vector I =  and surface normal N - lightDirection normal1 .reflect returns the reflection direction calculated as I - 2.0 * dot(N, I) * N.        N should be normalized in order to achieve the desired result.
  let reflectDirection = face.normal.reflect(-lightDir);
  origin = origin.normalize();
  //Takes only positive dot
  let lambertian = Math.max(lightDir.dot(face.normal), 0.0);
  let specular = 0.0;

  if (lambertian > 0.0) {
    let specAngle = max(reflectDirection.dot(origin), 0.0);
    specular = pow(specAngle, magnitude * 16.0 + 0.0000000001);
  }

  color = (ambientColor.x +
    lambertian * diffuseColor.x +
    specular * specColor.x,
  ambientColor.y + lambertian * diffuseColor.y + specular * specColor.y,
  ambientColor.z + lambertian * diffuseColor.z + specular * specColor.z);

*/

/*

let r =
      ambientColor.r +
      (this.lights[i].intensity * 1 * lambertian * diffuseColor.r) /
        lightDir.length() +
      specular * specColor.r;
    let g =
      ambientColor.g +
      (this.lights[0].intensity * 1 * lambertian * diffuseColor.g) /
        lightDir.length() +
      specular * specColor.g;
    let b =
      ambientColor.b +
      (this.lights[0].intensity * 1 * lambertian * diffuseColor.b) /
        lightDir.length() +
      specular * specColor.b;
    color.setRGB(r, g, b);

    */

/*
 let r =
      ambientColor.r +
      attenuation * lambertian * diffuseColor.r +
      specular * specColor.r;
    let g =
      ambientColor.g +
      attenuation * lambertian * diffuseColor.g +
      specular * specColor.g;
    let b =
      ambientColor.b +
      attenuation * lambertian * diffuseColor.b +
      specular * specColor.b;
    color.setRGB(r, g, b);



    */

/* Today before
        //Takes only positive dot
    let lambertian = Math.max(lightDir.dot(normal), 0.0000001);
    // let lambertian = Math.max(lightDir.dot(normal), 0);
    let specular = 0.0;

    if (lambertian > 0.0) {
      let specAngle = Math.max(reflectDirection.dot(eyeVector), 0.0);
      specular = Math.pow(specAngle, magnitude * 16.0 + 0.0000000001);
    }

    let r =
      ambientColor.r +
      attenuation * lambertian * diffuseColor.r +
      specular * specColor.r;
    let g =
      ambientColor.g +
      attenuation * lambertian * diffuseColor.g +
      specular * specColor.g;
    let b =
      ambientColor.b +
      attenuation * lambertian * diffuseColor.b +
      specular * specColor.b;
    color.setRGB(r, g, b);





    Got lot's of light in scene
        //Takes only positive dot
    let lambertian = Math.max(lightDir.dot(normal), 0.0000001);
    var diffuseIntensity = lambertian * this.lights[0].intensity;
    // let lambertian = Math.max(lightDir.dot(normal), 0);
    // let specular = 0.0;

    // if (lambertian > 0.0) {
    //   let specAngle = Math.max(reflectDirection.dot(eyeVector), 0.0);
    //   specular = Math.pow(specAngle, magnitude * 16.0 + 0.0000000001);
    // }
    var lightContribution = new THREE.Color();
    lightColor.copyGammaToLinear(this.lights[0].color);

    if (
      material.isMeshLambertMaterial ||
      material.isMeshPhongMaterial ||
      material.isMeshBasicMaterial
    ) {
      diffuseColor.copyGammaToLinear(material.color);
    } else {
      diffuseColor.setRGB(1, 1, 1);
    }
    if (material.vertexColors === THREE.FaceColors) {
      diffuseColor.multiply(face.color);
    }
    lightContribution.copy(diffuseColor);
    lightContribution.multiply(lightColor);
    lightContribution.multiplyScalar(diffuseIntensity * attenuation);

    let r =
      ambientColor.r + attenuation * lambertian * diffuseColor.r + specColor.r;
    let g =
      ambientColor.g + attenuation * lambertian * diffuseColor.g + specColor.g;
    let b =
      ambientColor.b + attenuation * lambertian * diffuseColor.b + specColor.b;
    color.setRGB(r, g, b);
    color.add(lightContribution);
  } else {
    color.set(0, 0, 0);
  }
    */

/* Another try

    var lightColor = new THREE.Color();
  let diffuseColor = new THREE.Color();
  let ambientColor = new THREE.Color();
  // diffuseColor.copyGammaToLinear(material.color);
  let specColor = new THREE.Color();

  var eyeVector = new THREE.Vector3();
  var normal = new THREE.Vector3();

  var raycasterLight = new THREE.Raycaster();
  var rayLight = raycasterLight.ray;

  var point = intersection.point;
  var object = intersection.object;
  var material = object.material;
  var face = intersection.face;

  var geometry = object.geometry;

  var color = new THREE.Color(1, 1, 1);
  for (var i = 0; i < this.lights.length; i++) {
    rayLight.origin.copy(point);
    let lightDir = new THREE.Vector3();
    lightDir.setFromMatrixPosition(this.lights[i].matrixWorld);

    lightDir.sub(point);
    //To check if in the shadow
    rayLight.direction.copy(lightDir).normalize();

    var intersections = raycasterLight.intersectObjects(this.scene.children);
    //Eye Vektor
    // eyeVector.subVectors(origin, point).normalize();
    eyeVector.copy(point);
    eyeVector.multiplyScalar(-1);
    eyeVector.normalize();

    let isInShadow = intersections.length > 0;
    if (object.geometry.type == "BoxGeometry") {
      // geometry.computeVertexNormals(true);
      geometry.computeFaceNormals();
      geometry.normalsNeedUpdate = true;
      normal = face.normal;
      normal.applyQuaternion(object.quaternion);
    } else if (object.geometry.type == "SphereGeometry") {
      normal.subVectors(point, object.position).normalize();
    } else {
      console.log("Hi");
    }
    if (
      material.isMeshLambertMaterial ||
      material.isMeshPhongMaterial ||
      material.isMeshBasicMaterial
    ) {
      diffuseColor.copyGammaToLinear(material.color);
    } else {
      diffuseColor.setRGB(1, 1, 1);
    }
    if (material.vertexColors === THREE.FaceColors) {
      diffuseColor.multiply(face.color);
      // console.log("hi");
    }
    //
    if (!isInShadow) {
      // console.log(object.geometry.type);
      let magnitude = this.phongMagnitude;
      let ambientColor = new THREE.Color(0.1, 0.1, 0.1);

      let specColor = new THREE.Color(0.7, 0.7, 0.7);
      // specColor.copyGammaToLinear(material.specular);
      //Atteuation
      var attenuation = 1.0;
      if (this.lights[i].physicalAttenuation === true) {
        attenuation = lightDir.length();
        attenuation =
          (1.0 / (attenuation * attenuation)) * this.lights[i].intensity;
      }
      // attenuation = 1;

      lightDir.normalize();
      //For a given incident vector I =  and surface normal N - lightDirection normal1 .reflect returns the reflection direction calculated as I - 2.0 * dot(N, I) * N.        N should be normalized in order to achieve the desired result.

      // let reflectDirection = lightDir.reflect(normal);
      let reflectDirection = new THREE.Vector3();
      reflectDirection.copy(lightDir);
      reflectDirection.multiplyScalar(-1);
      reflectDirection.reflect(normal);

      //Takes only positive dot
      let lambertian = Math.max(lightDir.dot(normal), 0.0000001);
      // let lambertian = Math.max(lightDir.dot(normal), 0);
      let specular = 0.0;

      if (lambertian > 0.0) {
        let specAngle = Math.max(reflectDirection.dot(eyeVector), 0.0);
        specular = Math.pow(specAngle, magnitude * 16.0 + 0.0000000001);
      }

      let r =
        ambientColor.r +
        attenuation * lambertian * diffuseColor.r +
        specular * specColor.r;
      let g =
        ambientColor.g +
        attenuation * lambertian * diffuseColor.g +
        specular * specColor.g;
      let b =
        ambientColor.b +
        attenuation * lambertian * diffuseColor.b +
        specular * specColor.b;
      color.setRGB(r, g, b);
    } else {
      color.set(0, 0, 0);
    }
    // color.setRGB(0, 1, 0);
    // color.setRGB(normal.x, normal.y, normal.z);
    var reflectionVector = new THREE.Vector3();
    //Trying reflection
    if (material.mirror) {
      var reflectivity = material.reflectivity;
      reflectionVector.copy(origin);
      reflectionVector.reflect(normal);

      var theta = Math.max(eyeVector.dot(normal), 0.0);
      var rf0 = reflectivity;
      var fresnel = rf0 + (1.0 - rf0) * Math.pow(1.0 - theta, 5.0);
      var weight = fresnel;
      var zColor = new THREE.Color();

      if (material.specular !== undefined) {
        zColor.multiply(material.specular);
      }
      zColor.multiplyScalar(weight);
      color.multiplyScalar(1 - weight);
      // if (material.mirror && this.print < 6000) {
      //   console.log("Color= ", color);

      //   console.log("Color after= ", color);

      //   this.print++;
      // }
      // color = color.add(zColor);
    }
    pixelColor.set(color);
  }
};


    */
