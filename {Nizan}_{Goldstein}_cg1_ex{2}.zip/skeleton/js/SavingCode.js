// console.log(this.camera.projectionMatrix.elements);

this.bear2.traverse(node => {
  if (node.type == "Mesh") {
    console.log(node);
    node.geometry.vertices.verticesNeedUpdate = true;
    node.geometry.vertices.map(ver => {
      vec = new THREE.Vector4(ver.x, ver.y, ver.z);
      // console.log(vec);

      vec = vec.applyMatrix4(node.matrixWorld);
      // console.log("model", vec);
      vec = vec.applyMatrix4(this.perspectiveCamera.matrixWorldInverse);
      // console.log("view", vec);
      vec = vec.applyMatrix4(this.camera.projectionMatrix);
      // console.log("projection", vec);
      // console.log("/n");

      ver.x = vec.x;
      ver.y = vec.y;
      ver.z = vec.z;
      // console.log(ver);
      // ver.applyMatrix4(this.bear2.matrixWorld);
      // console.log("1 - ", ver);
      // ver.applyMatrix4(this.perspectiveCamera.matrixWorldInverse);
      // console.log("2 - ", ver);
      // ver.applyMatrix4(this.perspectiveCamera.projectionMatrix);
      // console.log("3 - ", ver);
    });
    console.log(node);
  }
});
this.bear2.updateMatrix();
this.bear2.updateMatrixWorld();
this.clipScene.add(this.bear2);

this.animate();

//

console.log(this.bear.matrixWorld.elements);
console.log(this.perspectiveCamera.projectionMatrix.elements);
var a = this.perspectiveCamera.projectionMatrix.multiply(this.bear.matrixWorld);
console.log(a);

//Trying to add bear 2
this.bear2 = createTeddyBear(this.params);
// this.clipScene.add(this.bear2);
// this.clipScene.add(leftArm);
// console.log(this.bear.matrixWorld);

SceneController.prototype.adjustClipView = function() {
  var axis = new THREE.AxisHelper(0.5);

  var leftArm = new THREE.Mesh(
    new THREE.BoxGeometry(0.1, 0.1, 0.1),
    new THREE.MeshLambertMaterial({
      color: "silver"
    })
  );
  var a = this.bear.children[0].children[3];
  var b = this.bear.children[0].children[4];
  // console.log(a);

  a.children[0].geometry.verticesNeedUpdate = true;
  a.children[0].geometry.vertices.map(ver => {
    vec = new THREE.Vector4(ver.x, ver.y, ver.z);
    // console.log(vec);
    vec = vec.applyMatrix4(a.matrixWorld);
    // console.log("model", vec);
    vec = vec.applyMatrix4(this.perspectiveCamera.matrixWorldInverse);
    // console.log("view", vec);
    vec = vec.applyMatrix4(this.perspectiveCamera.projectionMatrix);
    // console.log("projection", vec);
    // console.log("/n");

    ver.x = vec.x;
    ver.y = vec.y;
    ver.z = vec.z;
    // ver.x =
    //   ((((vec.x + 1) / 2) * window.innerWidth) / window.innerHeight / 3) * 0.01;
    // ver.y =
    //   ((((vec.y + 1) / 2) * window.innerWidth) / window.innerHeight / 3) * 0.01;
    // ver.z = -0.5;
    console.log(ver);
  });
  b.children[0].geometry.verticesNeedUpdate = true;
  b.children[0].geometry.vertices.map(ver => {
    vec = new THREE.Vector4(ver.x, ver.y, ver.z);
    // console.log(vec);
    vec = vec.applyMatrix4(b.matrixWorld);
    // console.log("model", vec);
    vec = vec.applyMatrix4(this.perspectiveCamera.matrixWorldInverse);
    // console.log("view", vec);
    vec = vec.applyMatrix4(this.perspectiveCamera.projectionMatrix);
    // console.log("projection", vec);
    // console.log("/n");

    ver.x = vec.x;
    ver.y = vec.y;
    ver.z = vec.z;
    // ver.x =
    //   ((((vec.x + 1) / 2) * window.innerWidth) / window.innerHeight / 3) * 0.01;
    // ver.y =
    //   ((((vec.y + 1) / 2) * window.innerWidth) / window.innerHeight / 3) * 0.01;
    // ver.z = -0.5;
    console.log(ver);
  });
  // a.updateMatrix();
  // a.updateMatrixWorld();
  // a.geometry.computeBoundingSphere();
  this.clipScene.add(axis);
  // this.clipScene.add(a);
  // this.clipScene.add(leftArm);
  // console.log(this.clipScene);

  // console.log(a);
  this.animate();
};
