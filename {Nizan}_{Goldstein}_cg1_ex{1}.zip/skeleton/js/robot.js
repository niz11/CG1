var Robot = function() {
  this.root = new THREE.Object3D();
};

Robot.prototype.buildRobot = function() {
  //Add axis to the root for help
  var axis = new THREE.AxisHelper(0.1);
  this.root.add(axis);
  //USefull root variables
  this.root.name = "Root";
  this.root.selectedNode = "none";
  this.root.bodyParts = [];
  //Torso
  var geometry = new THREE.BoxGeometry(0.2, 0.35, 0.2);
  // https://threejs.org/docs/#api/materials/MeshLambertMaterial
  var material = new THREE.MeshLambertMaterial({
    color: "silver" //Css color names
  });
  //a mesh consists of geometry and a material; added to the scene
  var torso = new THREE.Mesh(geometry, material); //A mesh is an object that takes a geometry, and applies a material to it, which we then can insert to our scene, and move freely around.
  torso.name = "Torso";
  this.root.add(torso);

  //Arms
  //left
  var leftArm = new THREE.Mesh(
    new THREE.BoxGeometry(0.1, 0.2, 0.1),
    new THREE.MeshLambertMaterial({
      color: "silver"
    })
  );
  leftArm.name = "leftArm";

  //Adding a Pivot for rotaion
  var pivot = new THREE.Mesh();
  pivot.name = "pivot";
  pivot.add(leftArm);

  //Right
  var rightArm = new THREE.Mesh(
    new THREE.BoxGeometry(0.1, 0.2, 0.1),
    new THREE.MeshLambertMaterial({
      color: "silver"
    })
  );
  //Adding a Pivot for rotaion
  var pivotRightArm = new THREE.Mesh();
  pivotRightArm.name = "pivot";
  pivotRightArm.add(rightArm);

  rightArm.name = "rightArm";
  // rotating the arms
  leftArm.rotateX(Math.PI / 2);
  leftArm.rotateZ(Math.PI / 2);

  rightArm.rotateX(Math.PI / 2);
  rightArm.rotateZ(-Math.PI / 2);

  // Legs
  //right
  var rightLeg = new THREE.Mesh(
    new THREE.BoxGeometry(0.11, 0.2, 0.1),
    new THREE.MeshLambertMaterial({
      color: "silver"
    })
  );
  rightLeg.name = "rightLeg";

  //Adding a Pivot for rotaion
  var pivotRightLeg = new THREE.Mesh();
  pivotRightLeg.name = "pivot";
  pivotRightLeg.add(rightLeg);

  var rightFoot = new THREE.Mesh(
    new THREE.BoxGeometry(0.11, 0.1, 0.06),
    new THREE.MeshLambertMaterial({
      color: "silver"
    })
  );
  rightFoot.name = "rightFoot";

  //Adding a Pivot for rotaion
  var pivotRightFoot = new THREE.Mesh();
  pivotRightFoot.name = "pivot";
  pivotRightFoot.add(rightFoot);

  rightLeg.add(pivotRightFoot);

  rightFoot.rotateX(Math.PI / 2);

  //Left
  //a mesh consists of geometry and a material; added to the scene
  var leftLeg = new THREE.Mesh(
    new THREE.BoxGeometry(0.11, 0.2, 0.1),
    new THREE.MeshLambertMaterial({
      color: "silver"
    })
  );
  leftLeg.name = "leftLeg";
  //Adding a Pivot for rotaion
  var pivotLeftLeg = new THREE.Mesh();
  pivotLeftLeg.name = "pivot";
  pivotLeftLeg.add(leftLeg);

  var leftFoot = new THREE.Mesh(
    new THREE.BoxGeometry(0.11, 0.1, 0.06),
    new THREE.MeshLambertMaterial({
      color: "silver"
    })
  );
  leftFoot.name = "leftFoot";

  //Adding a Pivot for rotaion
  var pivotLeftFoot = new THREE.Mesh();
  pivotLeftFoot.name = "pivot";
  pivotLeftFoot.add(leftFoot);

  leftLeg.add(pivotLeftFoot);

  leftFoot.rotateX(Math.PI / 2);

  //head
  var head = new THREE.Mesh(
    new THREE.SphereGeometry(0.1, 0.1, 0.1),
    new THREE.MeshBasicMaterial({ color: "silver" })
  );
  head.name = "head";

  //Adding a Pivot for rotaion
  var pivotHead = new THREE.Mesh();
  pivotHead.name = "pivot";
  pivotHead.add(head);
  //building the tree/sence graph
  torso.add(pivot);
  torso.add(pivotRightArm);
  torso.add(pivotLeftLeg);
  torso.add(pivotRightLeg);
  torso.add(pivotHead);

  //positoin on relate to torso
  //pivot left arm setting
  pivot.position.set(-0.12, 0.1, 0);
  leftArm.position.set(-0.13, 0, 0);

  //Adding pivot position
  pivotRightArm.position.set(0.12, 0.1, 0);
  rightArm.position.set(0.13, 0, 0);

  //Left leg
  pivotLeftLeg.position.set(-0.06, -0.21, 0);
  leftLeg.position.set(0, -0.12, 0);
  //leftFoot
  pivotLeftFoot.position.set(0, -0.07, 0.06);
  leftFoot.position.set(0, 0, 0.07);

  //Right leg
  pivotRightLeg.position.set(0.06, -0.21, 0);
  rightLeg.position.set(0, -0.12, 0);
  //Right foot
  pivotRightFoot.position.set(0, -0.07, 0.06);
  rightFoot.position.set(0, 0, 0.07);

  //head
  pivotHead.position.set(0, 0.2, 0);
  head.position.set(0, 0.1, 0);

  //Body patrs array for mouseClick event
  this.root.bodyParts.push(torso);
  this.root.bodyParts.push(leftArm);
  this.root.bodyParts.push(rightArm);
  this.root.bodyParts.push(leftLeg);
  this.root.bodyParts.push(rightLeg);
  this.root.bodyParts.push(leftFoot);
  this.root.bodyParts.push(rightFoot);
  this.root.bodyParts.push(head);

  this.root.add(torso);

  return this.root;
};

Robot.prototype.reset = function() {
  this.root.children[1].children.map(pivot => {
    pivot.rotation.set(0, 0, 0);
    if (
      pivot.children[0].name === "leftLeg" ||
      pivot.children[0].name === "rightLeg"
    ) {
      pivot.children[0].children[0].rotation.set(0, 0, 0);
    }
  });
  this.root.rotation.set(0, 0, 0);
};

Robot.prototype.selectChild = function(forward) {
  //Child
  if (forward === "s") {
    //selectedNode is the root, then slect the torso
    if (this.root.selectedNode === "none") {
      this.root.selectedNode = this.root.children[1];
      this.toggleSelection();
    } else {
      //No children ? end of the line - skip back to torso
      if (this.root.selectedNode.children.length === 0) {
        this.root.selectedNode.material.color = new THREE.Color("silver");
        this.root.children[1].material.color = new THREE.Color("yellow");
        this.root.selectedNode = this.root.children[1];
      } else {
        if (this.root.selectedNode.children[0].name === "pivot") {
          this.root.selectedNode.material.color = new THREE.Color("silver");
          this.root.selectedNode = this.root.selectedNode.children[0].children[0];
        }
        this.root.selectedNode.material.color = new THREE.Color("yellow");
      }
    }
  }

  //Parent
  if (forward === "w") {
    if (this.root.selectedNode === "none") {
      this.root.selectedNode = this.root.children[1];
      this.toggleSelection();
    } else {
      if (this.root.selectedNode.name === "Torso") {
        this.root.selectedNode.material.color = new THREE.Color("yellow");
      } else {
        if ((this.root.selectedNode.parent.name = "pivot")) {
          this.root.selectedNode.material.color = new THREE.Color("silver");
          this.root.selectedNode = this.root.selectedNode.parent.parent;
        }
        this.root.selectedNode.material.color = new THREE.Color("yellow");
      }
    }
  }
};

Robot.prototype.selectSibling = function(forward) {
  if (
    this.root.selectedNode === "none" ||
    this.root.selectedNode.name === "Torso"
  ) {
    this.root.selectedNode = this.root.children[1];
  } else {
    if (this.root.selectedNode.name === "leftFoot") {
      this.root.selectedNode.material.color = new THREE.Color("silver");
      this.root.selectedNode = this.root.children[1].children[3].children[0].children[0].children[0];
    } else {
      if (this.root.selectedNode.name === "rightFoot") {
        this.root.selectedNode.material.color = new THREE.Color("silver");
        this.root.selectedNode = this.root.children[1].children[2].children[0].children[0].children[0];
      } else {
        this.root.selectedNode.material.color = new THREE.Color("silver");
        let index = this.root.children[1].children.findIndex(
          node => node.children[0].name === this.root.selectedNode.name
        );
        //Moving to the right side of the array
        let moveOneCell;
        {
          forward === "d" ? (moveOneCell = 1) : (moveOneCell = -1);
        }
        index = index + moveOneCell;
        {
          index === 5 ? (index = 0) : index === -1 ? (index = 4) : index;
        }

        this.root.selectedNode = this.root.selectedNode.parent.parent.children[
          index
        ].children[0];
      }
    }
    this.root.selectedNode.material.color = new THREE.Color("yellow");
  }
};

Robot.prototype.toggleSelection = function() {

  var yellow = new THREE.Color("yellow");
  {
    this.root.selectedNode === "none"
      ? ((this.root.selectedNode = this.root.children[1]),
        (this.root.selectedNode.material.color = new THREE.Color("yellow")))
      : this.root.selectedNode.material.color.equals(yellow)
        ? ((this.root.selectedNode.material.color = new THREE.Color("silver")),
          (this.root.selectedNode = "none"))
        : (this.root.selectedNode.material.color = new THREE.Color("yellow"));
  }
};

Robot.prototype.rotateOnAxis = function(axis, degree) {
  if (this.root.selectedNode === "none") {
    console.log("Select to rotate");
  } else {
    this.root.selectedNode.parent.rotation.x += degree * axis.x;
    this.root.selectedNode.parent.rotation.y += degree * axis.y;
    this.root.selectedNode.parent.rotation.z += degree * axis.z;
  }
};

Robot.prototype.changePotition = function(screenX, screenY) {
  if (this.root.selectedNode === "none") {
    console.log("Select to rotate");
  } else {
    this.root.selectedNode.parent.rotation.y += screenX / 100;
    this.root.selectedNode.parent.rotation.x += screenY / 100;
  }
};

Robot.prototype.toggleAxisVisibility = function() {
  //Adding Axis
  // x is red
  // y is green
  // z is blue

  if (this.root.children[1].children[0].children.length < 2) {
    this.root.children[1].children.map(pivot => {
      pivot.add(new THREE.AxisHelper(0.1));
      if (
        pivot.children[0].name === "leftLeg" ||
        pivot.children[0].name === "rightLeg"
      ) {
        pivot.children[0].children[0].add(new THREE.AxisHelper(0.1));
      }
    });
  } else {
    this.root.children[1].children.map(pivot => {
      pivot.remove(pivot.children[1]);
      if (
        pivot.children[0].name === "leftLeg" ||
        pivot.children[0].name === "rightLeg"
      ) {
        pivot.children[0].children[0].remove(
          pivot.children[0].children[0].children[1]
        );
      }
    });
  }
};
